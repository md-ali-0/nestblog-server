export const jwtConstants = {
  secret:
    '331dabb383bb3b83f3f47ac27f9c786f3a69275a69fdb954eb30e361442a07c869e58b39e2eb428706159996f0cafb285e44d5dca65b03e7c318ac8d6df085bd',
};
